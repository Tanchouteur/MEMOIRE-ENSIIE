package src;

public class Main {

    public static void main(String[] args) {
        GameControler game = new GameControler();
        game.start();
    }
}
