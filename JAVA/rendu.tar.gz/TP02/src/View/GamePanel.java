package src.View;

import src.Model.Gameplay.Board;

import javax.swing.*;

public class GamePanel extends JRootPane {
    public GamePanel(Board board) {
        // Initialize the game panel with the board

    }
}
