package src.Model.Monster;

public class Pikatchu extends Monster{
    public Pikatchu(double x, double y) {
        super("Pikatchu", 100, x, y);
    }
}
