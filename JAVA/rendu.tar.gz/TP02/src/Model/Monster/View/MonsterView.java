package src.Model.Monster.View;

import javax.swing.*;

public abstract class MonsterView extends JComponent {

}
