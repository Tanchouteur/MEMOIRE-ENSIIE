package src.Model.Weapon;

public class Sword extends Weapon{
    public Sword() {
        super("Sword", 15, 2);
    }
}
