package src.Model.Weapon;

public class Knife  extends Weapon{
    public Knife() {
        super("Knife", 10, 1);
    }
}
